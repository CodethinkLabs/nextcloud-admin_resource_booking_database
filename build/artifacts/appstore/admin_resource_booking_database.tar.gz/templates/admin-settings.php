<?php
script('admin_resource_booking_database', 'settings');
style('admin_resource_booking_database', 'settings');
?>

<div id="admin_resource_booking_database"></div>